(function () {
  if (window.__SESLISEVDA_BRIDGE_LOADED__) return;
  window.__SESLISEVDA_BRIDGE_LOADED__ = true;

  var wakeLock = null;
  var heartbeatTimer = null;

  function tryPlayAll() {
    try {
      var nodes = document.querySelectorAll('audio,video');
      for (var i = 0; i < nodes.length; i++) {
        try {
          nodes[i].muted = false;
          var p = nodes[i].play();
          if (p && p.catch) p.catch(function () {});
        } catch (e) {}
      }
    } catch (e) {}
  }

  function resumeAudioContexts() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (window.__SESLI_CTX__ && window.__SESLI_CTX__.state === 'suspended') {
        window.__SESLI_CTX__.resume && window.__SESLI_CTX__.resume().catch(function () {});
      }
    } catch (e) {}
  }

  async function requestWakeLock() {
    try {
      if (!('wakeLock' in navigator)) return;
      if (document.visibilityState !== 'visible') return;
      wakeLock = await navigator.wakeLock.request('screen');
      wakeLock.addEventListener('release', function () {
        wakeLock = null;
      });
    } catch (e) {}
  }

  function pokeReconnects() {
    try {
      if (window.ws && typeof window.ws.readyState !== 'undefined' && window.ws.readyState > 1 && typeof window.connectWS === 'function') {
        window.connectWS();
      }
    } catch (e) {}
    try {
      if (typeof window.reconnectWebSocket === 'function') window.reconnectWebSocket();
    } catch (e) {}
    try {
      if (typeof window.ensureWsConnected === 'function') window.ensureWsConnected();
    } catch (e) {}
  }

  function recover() {
    resumeAudioContexts();
    tryPlayAll();
    pokeReconnects();
    requestWakeLock();
  }

  function startHeartbeat() {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    heartbeatTimer = setInterval(function () {
      if (document.visibilityState === 'visible') {
        recover();
      }
    }, 4 * 60 * 1000);
  }

  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState === 'visible') recover();
  }, true);

  window.addEventListener('focus', recover, true);
  window.addEventListener('pageshow', recover, true);
  window.addEventListener('online', recover, true);
  document.addEventListener('click', recover, true);
  document.addEventListener('touchstart', recover, true);

  window.__SESLISEVDA_RECOVER__ = recover;
  startHeartbeat();
  setTimeout(recover, 400);
})();

package com.seslichat.mobile

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar
import com.seslichat.mobile.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermissionRequest: PermissionRequest? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var lastLoadedUrl: String = BuildConfig.BASE_URL
    private var audioManager: AudioManager? = null
    private var audioFocusRequest: AudioFocusRequest? = null
    private var hasLoadedOnce = false

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val grantedMic = result[Manifest.permission.RECORD_AUDIO] == true
        val grantedCam = result[Manifest.permission.CAMERA] == true

        pendingPermissionRequest?.let { request ->
            val resources = request.resources.toList()
            val allowAudio = !resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE) || grantedMic
            val allowVideo = !resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE) || grantedCam
            if (allowAudio && allowVideo) {
                request.grant(request.resources)
            } else {
                request.deny()
                toastBanner("Mikrofon / kamera izni olmadan bazı özellikler çalışmayabilir.")
            }
        }
        pendingPermissionRequest = null
    }

    private val filePickerLauncher = registerForActivityResult(
        ActivityResultContracts.GetMultipleContents()
    ) { uris ->
        val result = uris.toTypedArray()
        fileChooserCallback?.onReceiveValue(if (result.isEmpty()) null else result)
        fileChooserCallback = null
    }

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            runOnUiThread {
                binding.statusBadge.text = getString(R.string.status_online)
                binding.statusBadge.setBackgroundResource(R.drawable.bg_status_online)
                recoverWebAudio()
                if (hasLoadedOnce) {
                    binding.webView.evaluateJavascript("window.location && window.location.href;", null)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        lastLoadedUrl = savedInstanceState?.getString(KEY_LAST_URL) ?: BuildConfig.BASE_URL

        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        setupInsets()
        setupButtons()
        setupSwipeRefresh()
        setupWebView()
        requestCorePermissions()
        registerNetworkCallback()
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        requestAudioFocus()
        binding.webView.onResume()
        recoverWebAudio()
    }

    override fun onPause() {
        binding.webView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterNetworkCallback()
        abandonAudioFocus()
        binding.webView.apply {
            stopLoading()
            webChromeClient = null
            webViewClient = null
            destroy()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_LAST_URL, lastLoadedUrl)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> hideCustomView()
            binding.webView.canGoBack() -> binding.webView.goBack()
            else -> super.onBackPressed()
        }
    }

    private fun setupInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { _, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.topStatusWrap.setPadding(
                binding.topStatusWrap.paddingLeft,
                bars.top + dp(12),
                binding.topStatusWrap.paddingRight,
                binding.topStatusWrap.paddingBottom
            )
            binding.bottomDock.setPadding(
                binding.bottomDock.paddingLeft,
                binding.bottomDock.paddingTop,
                binding.bottomDock.paddingRight,
                bars.bottom + dp(10)
            )
            insets
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val cookies = CookieManager.getInstance()
        cookies.setAcceptCookie(true)
        cookies.setAcceptThirdPartyCookies(webView, true)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            loadsImagesAutomatically = true
            mediaPlaybackRequiresUserGesture = false
            useWideViewPort = true
            loadWithOverviewMode = true
            displayZoomControls = false
            builtInZoomControls = false
            javaScriptCanOpenWindowsAutomatically = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowContentAccess = true
            allowFileAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            userAgentString = userAgentString + " SesliChatAndroid/1.0"
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
            WebSettingsCompat.setAlgorithmicDarkeningAllowed(webView.settings, true)
        }

        webView.webChromeClient = buildChromeClient()
        webView.webViewClient = buildClient()
        webView.loadUrl(lastLoadedUrl)
    }

    private fun buildChromeClient(): WebChromeClient {
        return object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                binding.progressBar.progress = newProgress
                binding.progressBar.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
                if (newProgress >= 100) binding.swipeRefresh.isRefreshing = false
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                binding.statusText.text = title?.takeIf { it.isNotBlank() } ?: getString(R.string.app_name)
            }

            override fun onPermissionRequest(request: PermissionRequest?) {
                val req = request ?: return
                runOnUiThread {
                    val needMic = req.resources.contains(PermissionRequest.RESOURCE_AUDIO_CAPTURE)
                    val needCam = req.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    val micGranted = hasPermission(Manifest.permission.RECORD_AUDIO)
                    val camGranted = hasPermission(Manifest.permission.CAMERA)

                    if ((!needMic || micGranted) && (!needCam || camGranted)) {
                        req.grant(req.resources)
                    } else {
                        pendingPermissionRequest = req
                        val ask = mutableListOf<String>()
                        if (needMic && !micGranted) ask += Manifest.permission.RECORD_AUDIO
                        if (needCam && !camGranted) ask += Manifest.permission.CAMERA
                        permissionLauncher.launch(ask.toTypedArray())
                    }
                }
            }

            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                callback?.invoke(origin, true, false)
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = filePathCallback
                filePickerLauncher.launch("*/*")
                return true
            }

            override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message?): Boolean {
                val hit = view?.hitTestResult?.extra
                if (!hit.isNullOrBlank()) {
                    openExternal(hit)
                    return true
                }
                return false
            }

            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                binding.fullscreenContainer.addView(
                    view,
                    ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                )
                binding.fullscreenContainer.visibility = View.VISIBLE
                binding.webView.visibility = View.GONE
                hideSystemBars()
            }

            override fun onHideCustomView() {
                hideCustomView()
            }
        }
    }

    private fun buildClient(): WebViewClient {
        return object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return when (uri.scheme?.lowercase()) {
                    "http", "https" -> {
                        if (isTrustedHost(uri.host)) false else {
                            openExternal(uri.toString())
                            true
                        }
                    }
                    "tel", "mailto", "intent", "market" -> {
                        openExternal(uri.toString())
                        true
                    }
                    else -> false
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                lastLoadedUrl = url ?: lastLoadedUrl
                binding.statusBadge.text = getString(R.string.status_loading)
                binding.statusBadge.setBackgroundResource(R.drawable.bg_status_loading)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                lastLoadedUrl = url ?: lastLoadedUrl
                hasLoadedOnce = true
                binding.swipeRefresh.isRefreshing = false
                binding.statusBadge.text = getString(R.string.status_online)
                binding.statusBadge.setBackgroundResource(R.drawable.bg_status_online)
                injectBridgeScript()
                recoverWebAudio()
            }

            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                super.onReceivedError(view, request, error)
                if (request?.isForMainFrame == true) {
                    binding.swipeRefresh.isRefreshing = false
                    binding.statusBadge.text = getString(R.string.status_problem)
                    binding.statusBadge.setBackgroundResource(R.drawable.bg_status_problem)
                    toastBanner("Bağlantı sorunu oluştu. Yeniden deneniyor.")
                }
            }
        }
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            binding.webView.reload()
        }
    }

    private fun setupButtons() {
        binding.btnBack.setOnClickListener {
            if (binding.webView.canGoBack()) binding.webView.goBack()
        }
        binding.btnHome.setOnClickListener { binding.webView.loadUrl(BuildConfig.BASE_URL) }
        binding.btnRefresh.setOnClickListener { binding.webView.reload() }
        binding.btnExternal.setOnClickListener { openExternal(lastLoadedUrl) }
        binding.btnMore.setOnClickListener { showMoreSheet() }
    }

    private fun requestCorePermissions() {
        val wanted = mutableListOf<String>()
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) wanted += Manifest.permission.RECORD_AUDIO
        if (!hasPermission(Manifest.permission.CAMERA)) wanted += Manifest.permission.CAMERA
        if (wanted.isNotEmpty()) permissionLauncher.launch(wanted.toTypedArray())
    }

    private fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(this, permission) == android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    private fun injectBridgeScript() {
        val bridge = assets.open("app_bridge.js").bufferedReader().use { it.readText() }
        binding.webView.evaluateJavascript(bridge, null)
    }

    private fun recoverWebAudio() {
        val js = """
            (function(){
              try {
                if (window.__SESLISEVDA_RECOVER__) window.__SESLISEVDA_RECOVER__();
                var media = document.querySelectorAll('audio,video');
                for (var i = 0; i < media.length; i++) {
                  try {
                    media[i].muted = false;
                    media[i].volume = Math.max(media[i].volume || 1, 0.01);
                    var p = media[i].play();
                    if (p && p.catch) p.catch(function(){});
                  } catch(e) {}
                }
              } catch(e) {}
            })();
        """.trimIndent()
        binding.webView.evaluateJavascript(js, null)
    }

    private fun requestAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (audioFocusRequest == null) {
                audioFocusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setOnAudioFocusChangeListener {
                        if (it == AudioManager.AUDIOFOCUS_GAIN) recoverWebAudio()
                    }
                    .build()
            }
            manager.requestAudioFocus(audioFocusRequest!!)
        } else {
            @Suppress("DEPRECATION")
            manager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN)
        }
    }

    private fun abandonAudioFocus() {
        val manager = audioManager ?: return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            audioFocusRequest?.let { manager.abandonAudioFocusRequest(it) }
        } else {
            @Suppress("DEPRECATION")
            manager.abandonAudioFocus(null)
        }
    }

    private fun registerNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            cm.registerDefaultNetworkCallback(networkCallback)
        } catch (_: Throwable) {}
    }

    private fun unregisterNetworkCallback() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            cm.unregisterNetworkCallback(networkCallback)
        } catch (_: Throwable) {}
    }

    private fun openExternal(url: String): Boolean {
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            true
        } catch (_: ActivityNotFoundException) {
            toastBanner("Bağlantı açılamadı")
            false
        }
    }

    private fun showMoreSheet() {
        val items = arrayOf("Ana sayfa", "Yeniden bağlan", "Önbelleği temizle", "Harici aç", "Çık")
        MaterialAlertDialogBuilder(this)
            .setTitle("Hızlı İşlemler")
            .setItems(items) { dialog, which ->
                when (which) {
                    0 -> binding.webView.loadUrl(BuildConfig.BASE_URL)
                    1 -> {
                        recoverWebAudio()
                        binding.webView.reload()
                    }
                    2 -> {
                        binding.webView.clearCache(true)
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        binding.webView.loadUrl(BuildConfig.BASE_URL)
                    }
                    3 -> openExternal(lastLoadedUrl)
                    4 -> finish()
                }
                dialog.dismiss()
            }
            .show()
    }

    private fun hideCustomView() {
        customView?.let {
            binding.fullscreenContainer.removeView(it)
            binding.fullscreenContainer.visibility = View.GONE
            binding.webView.visibility = View.VISIBLE
            customViewCallback?.onCustomViewHidden()
        }
        customView = null
        customViewCallback = null
        hideSystemBars()
    }

    private fun hideSystemBars() {
        val controller = WindowInsetsControllerCompat(window, binding.root)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun toastBanner(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_LONG).show()
    }

    private fun isTrustedHost(host: String?): Boolean {
        val safeHost = host?.lowercase() ?: return false
        return BuildConfig.TRUSTED_HOSTS.any { trusted ->
            val trustedLc = trusted.lowercase()
            safeHost == trustedLc || safeHost.endsWith(".$trustedLc")
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val KEY_LAST_URL = "last_url"
    }
}
